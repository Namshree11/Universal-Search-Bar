from tkinter import *
from tkinter import ttk,messagebox
import webbrowser


def search():
    if questionField.get()!='':
        if temp.get()=='google':
            webbrowser.open(f'https://www.google.com/search?q={questionField.get()}')

        if temp.get()=='instagram':
            webbrowser.open(f'https://www.instagram.com/search?q={questionField.get()}')

        if temp.get()=='amazon':
            webbrowser.open(f'https://www.amazon.com/s?k={questionField.get()}&ref=nb_sb_noss')

        if temp.get() == 'youtube':
            webbrowser.open(f'http://youtube.com/results?search_query={questionField.get()}')

    else:
        messagebox.showerror('Error','There is nothing to be searched')


root=Tk()

root.geometry('660x70+100+100')
root.title('Universal Search Bar')
root.iconbitmap('icon.ico')
root.config(bg='lightgrey')
root.resizable(0,0)

temp=StringVar()

style=ttk.Style()
style.theme_use('default')

queryLabel=Label(root,text='Query',font=('arial',14,'bold'),bg='lightgrey')
queryLabel.grid(row=0,column=0)

questionField=Entry(root,width=45,font=('arial',14,'bold'),bd=4,relief=SUNKEN)
questionField.grid(padx=10,row=0,column=1)



searchImage=PhotoImage(file='search.png')

searchButton=Button(root,image=searchImage,bd=0,cursor='hand2',bg='lightgrey',activebackground='lightgrey'
                    ,command=search)
searchButton.grid(row=0,column=3,padx=5)

googleRadioButton=ttk.Radiobutton(root,text='Google',value='google',variable=temp)
googleRadioButton.place(x=75,y=40)

instagramRadioButton=ttk.Radiobutton(root,text='Instagram',value='instagram',variable=temp)
instagramRadioButton.place(x=200,y=40)

amzonRadioButton=ttk.Radiobutton(root,text='Amazon',value='amazon',variable=temp)
amzonRadioButton.place(x=380,y=40)

youtubeRadioButton=ttk.Radiobutton(root,text='Youtube',value='youtube',variable=temp)
youtubeRadioButton.place(x=510,y=40)

def enter_function(value):
    searchButton.invoke()

root.bind('<Return>',enter_function)

temp.set('google')

root.mainloop()